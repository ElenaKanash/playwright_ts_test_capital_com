//window = self;
let _cpEnv = {};
const actionsMap = {
    'workerInit': initWorker,
    'pusherInit': livePricesInitPusher,
    'pusherSubscribe': livePricesSubscribe,
    'pusherUnsubscribe': livePricesUnsubscribe,
    'APICallRequest': APICallRequest
}

self.onmessage = function (e) {
    if (e.data.action && actionsMap[e.data.action]) {
        actionsMap[e.data.action](e.data.data);
    }
}
function sendMessage(action, data) {
    self.postMessage({ action, data });
}

/*
    proxyUrl: pURL,
    deviceId: deviceId,
    appVersion: appVersion,replace
    trackingSID: tSID,
    pageUrl: document.location.href
 */

function initWorker(data) {
    _cpEnv = data;
}

// ========================== pusher ==================================

let pusher;
function livePricesInitPusher() {
    if (pusher) return;
    importScripts("/js/vendor/pusher.worker.min.js"); // change to static after release
    pusher = new Pusher("app_key", {
        enabledTransports: ['ws'],
        wsHost: 'pusher-cc.backend-capital.com',
        disableStats: true
    });
    pusher.connection.strategy.transports.ws.transport.manager.livesLeft = 1000000;
}

let pusherMarkets = {};
function livePricesSubscribe(data) {
    if (!pusher) livePricesInitPusher();
    Object.keys(data).forEach((k) => {
        pusherMarkets[k] = data[k];
        pusherMarkets[k].updateFn = livePricesGetUpdateFn(k);
        pusher.subscribe('' + k).bind('bbo', pusherMarkets[k].updateFn);
    });
    fetch(_cpEnv.proxyUrl + "/trading/v1/quoteCurrent", {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json; charset=utf-8'
        },
        body: JSON.stringify({
            instrumentId: Object.keys(pusherMarkets)
        }),
    }).then((d) => d.json()).then((d) => {
        if (d) {
            for (var i in d.quotes) {
                if (pusherMarkets[d.quotes[i].instrumentId]) {
                    pusherMarkets[d.quotes[i].instrumentId].updateFn(d.quotes[i]);
                }
            }
        }
    });
}

function livePricesGetUpdateFn(id) {
    return function (d) {
        if (!pusherMarkets[id] || !d.bid || !d.ask) return;
        let data = {
            sellClass: 0,
            buyClass: 0,
            id: id,
            ts: d.ts ?? d.timestamp
        };
        let hasChange = false;
        let sell = +d.bid;
        data.sell = sell.toFixed(pusherMarkets[id].digits);
        if (d.bid != pusherMarkets[id].sell) {
            hasChange = true;
            if (pusherMarkets[id].sell !== undefined) {
                data.sellClass = pusherMarkets[id].sell > sell ? -1 : 1;
            }
            pusherMarkets[id].sell = sell;
        }
        let buy = +d.ask;
        data.buy = buy.toFixed(pusherMarkets[id].digits);
        if (d.ask != pusherMarkets[id].buy) {
            hasChange = true;
            if (pusherMarkets[id].buy !== undefined) {
                data.buyClass = pusherMarkets[id].buy > buy ? -1 : 1;
            }
            pusherMarkets[id].buy = buy;
            if (pusherMarkets[id].low !== null) {
                if (pusherMarkets[id].buy < pusherMarkets[id].low) {
                    pusherMarkets[id].low = pusherMarkets[id].buy
                    data.low = pusherMarkets[id].low;
                }
            }
            if (pusherMarkets[id].high !== null) {
                if (pusherMarkets[id].buy > pusherMarkets[id].high) {
                    pusherMarkets[id].high = pusherMarkets[id].buy
                    data.low = pusherMarkets[id].high;
                }
            }
        }

        data.spread = (pusherMarkets[id].buy - pusherMarkets[id].sell).toFixed(pusherMarkets[id].digits);

        if (hasChange) { //only if have any changes
            sendMessage('pusherPrice', data);
        }
    };
}

function livePricesUnsubscribe() {
    if (!pusher) livePricesInitPusher();
    Object.keys(pusherMarkets).forEach((channel) => {
        var ch = pusher.channel(channel);
        if (ch) {
            ch.unbind();
            pusher.unsubscribe(channel);
        }
    });
    pusherMarkets = {};
}
// ========================== END pusher ==================================


function ajaxRequest(url, requestData, options) {
    let request = {
        method: options && options.method == 'GET' ? 'POST' : 'POST',
    };
    if (options && options.headers) {
        request.headers = headers;
    }
    if (request.method == "POST" && requestData) {
        const formData = new FormData();
        Object.keys(requestData).forEach((k) => formData.append(k, requestData[k]));
        request.body = formData;
    }
    return fetch(url, request);
}


function ajaxRequestJSON(url, requestData, options) {
    let requestHeaders = {
        'Content-Type': 'application/json; charset=utf-8',
        'Accept': 'application/json'
    }
    options && options.headers && Object.keys(options.headers).forEach((k) => requestHeaders[k] = options.headers[k]);
    let request = {
        method: options && options.method == 'GET' ? 'GET' : 'POST',
        headers: requestHeaders
    };
    if (request.method == "POST" && requestData) {
        request.body = JSON.stringify(requestData ? requestData : {});
    }
    if (options.sendCookies) {
        request.headers['Access-Control-Allow-Origin'] = "*";
        request.credentials = 'include';  // 'same-origin', // include, *same-origin, omit
        request.mode = 'cors'; // // no-cors, *cors, same-origin
    }

    let p = new Promise(function (resolve, reject) {
        fetch(url, request).then((response) => {
            response.text().then(text => {
                let json;
                try {
                    json = JSON.parse(text);
                    if (response.status == 200) {
                        resolve(json);
                        return;
                    } else if (json.errorCode && json.errorCode != "BAD_REQUEST") {
                        reject([json.errorCode, (response.statusText || "") + "|" + (response.status || ""), json.params ? json.params : null]);
                        return;
                    }
                } catch (e) { };

                if (+response.status > 299) {
                    reject(['HZ', (response.statusText || "") + "|" + (response.status || "") + text]);
                } else {
                    reject(['HZ', (response.statusText || "") + "|" + (response.status || "")])
                }
            });
        })
            .catch((error) => {
                reject(['HZ', error])
            });
    });
    return p;
}

function logAPIError(msg) {
    return ajaxRequest('/service', {
        mode: 'jslog',
        type: 'apierror',
        url: _cpEnv.pageUrl,
        msg: msg
    });
}

function APICallRequest(data) {
    APICallWorker(data.action, data.requestData, data.sid, {
        sendCookies: data.sendCookies,
        noProxy: data.noProxy,
        method: data.method,
    }).then((d) => {
        sendMessage('APICallResponse', { status: 'ok', rid: data.rid, response: d });
    }).catch(([code, text, params]) => {
        sendMessage('APICallResponse', { status: 'error', rid: data.rid, response: { errorCode: code, errorText: text, params: params } });
    });
}


function APICallWorker(action, requestData, sid, options) {  //opts sendCookies, noProxy
    options = options || {};
    let headers = {
        "Device-Id": _cpEnv.deviceId,
        'App-Version': _cpEnv.appVersion,
        'Tracking-Session-Id': _cpEnv.trackingSID,
        'Random-Request-Uuid': generateNewUUID()
    };
    sid && (headers["Session-Token"] = sid);

    let p = new Promise(function (resolve, reject) {

        ajaxRequestJSON(_cpEnv.proxyUrl + "/v1/api/" + action, requestData, {
            headers,
            sendCookies: !!options.sendCookies,
            method: options.method
        })
            .then(d => resolve(d))
            .catch(([code, text, params]) => {
                // if (!options.noProxy && code == "HZ" && action != 'country.detect') {
                if (false) {
                    logAPIError("proxy|" + action + "|" + _cpEnv.deviceId + "|" + text).catch(() => reject([code, text]));
                    ajaxRequestJSON("/proxy/v1/api/" + action, requestData, {
                        headers,
                        sendCookies: !!options.sendCookies
                    }).then((d) => {
                        resolve(d);
                        logAPIError("siteok|" + action + "|" + _cpEnv.deviceId + "|" + text).catch(() => reject([code, text]));
                    }).catch(([code, text]) => {
                        logAPIError("siteok|" + action + "|" + _cpEnv.deviceId + "|" + text)
                            .then((d) => d.text())
                            .then((logId) => {
                                reject([code, text + "#" + logId]);
                            })
                            .catch(() => reject([code, text]));
                    });
                } else {
                    reject([code, text, params]);
                }
            });

    });
    return p;
}

// =========================== gen UUID =====================

function byteToHex(d) {
    return ("0" + (Number(d).toString(16))).slice(-2).toLowerCase();
}

function stringifyUUID(arr) {
    var uuid = (
        byteToHex(arr[0]) +
        byteToHex(arr[1]) +
        byteToHex(arr[2]) +
        byteToHex(arr[3]) +
        '-' +
        byteToHex(arr[4]) +
        byteToHex(arr[5]) +
        '-' +
        byteToHex(arr[6]) +
        byteToHex(arr[7]) +
        '-' +
        byteToHex(arr[8]) +
        byteToHex(arr[9]) +
        '-' +
        byteToHex(arr[10]) +
        byteToHex(arr[11]) +
        byteToHex(arr[12]) +
        byteToHex(arr[13]) +
        byteToHex(arr[14]) +
        byteToHex(arr[15])
    ).toLowerCase();

    return uuid;
}

function f(s, x, y, z) {
    switch (s) {
        case 0:
            return (x & y) ^ (~x & z);
        case 1:
            return x ^ y ^ z;
        case 2:
            return (x & y) ^ (x & z) ^ (y & z);
        case 3:
            return x ^ y ^ z;
    }
}

function ROTL(x, n) {
    return (x << n) | (x >>> (32 - n));
}

function sha1forUUID(bytes) {
    var K = [0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6];
    var C0 = 0x67452301;
    var C1 = 0xefcdab89;
    var C2 = 0x98badcfe;
    var C3 = 0x10325476;
    var C4 = 0xc3d2e1f0;
    var H = [C0, C1, C2, C3, C4];

    if (typeof bytes === 'string') {
        var msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

        bytes = [];

        for (var i = 0; i < msg.length; ++i) {
            bytes.push(msg.charCodeAt(i));
        }
    } else if (!Array.isArray(bytes)) {
        // Convert Array-like to Array
        bytes = Array.prototype.slice.call(bytes);
    }

    bytes.push(0x80);

    var l = bytes.length / 4 + 2;
    var N = Math.ceil(l / 16);
    var M = new Array(N);

    for (var i = 0; i < N; ++i) {
        var arr = new Uint32Array(16);

        for (var j = 0; j < 16; ++j) {
            arr[j] =
                (bytes[i * 64 + j * 4] << 24) |
                (bytes[i * 64 + j * 4 + 1] << 16) |
                (bytes[i * 64 + j * 4 + 2] << 8) |
                bytes[i * 64 + j * 4 + 3];
        }

        M[i] = arr;
    }

    M[N - 1][14] = ((bytes.length - 1) * 8) / Math.pow(2, 32);
    M[N - 1][14] = Math.floor(M[N - 1][14]);
    M[N - 1][15] = ((bytes.length - 1) * 8) & 0xffffffff;

    for (var i = 0; i < N; ++i) {
        var W = new Uint32Array(80);

        for (var t = 0; t < 16; ++t) {
            W[t] = M[i][t];
        }

        for (var t = 16; t < 80; ++t) {
            W[t] = ROTL(W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16], 1);
        }

        var a = H[0];
        var b = H[1];
        var c = H[2];
        var d = H[3];
        var e = H[4];

        for (var t = 0; t < 80; ++t) {
            var s = Math.floor(t / 20);
            var T = (ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[t]) >>> 0;
            e = d;
            d = c;
            c = ROTL(b, 30) >>> 0;
            b = a;
            a = T;
        }

        H[0] = (H[0] + a) >>> 0;
        H[1] = (H[1] + b) >>> 0;
        H[2] = (H[2] + c) >>> 0;
        H[3] = ((((H[0] + C0) >>> 0) ^ (((ROTL(H[1], 16) & 0x0fffffff) + C1) >>> 0) ^ (((H[2] & 0x3fffffff) + C2) >>> 0)) + C3) >>> 0;
        H[4] = (H[4] + e) >>> 0;
    }


    return [
        (H[0] >> 24) & 0xff,
        (H[0] >> 16) & 0xff,
        (H[0] >> 8) & 0xff,
        H[0] & 0xff,
        (H[1] >> 24) & 0xff,
        (H[1] >> 16) & 0xff,
        (H[1] >> 8) & 0xff, // uuid[6]
        H[1] & 0xff,
        (H[2] >> 24) & 0xff, // uuid[8]
        (H[2] >> 16) & 0xff,
        (H[2] >> 8) & 0xff,
        H[2] & 0xff,
        (H[3] >> 24) & 0xff,
        (H[3] >> 16) & 0xff,
        (H[3] >> 8) & 0xff,
        H[3] & 0xff,
        (H[4] >> 24) & 0xff,
        (H[4] >> 16) & 0xff,
        (H[4] >> 8) & 0xff,
        H[4] & 0xff,
    ];
}

function formatV4UUID(uuid) {
    uuid[6] = (uuid[6] & 0x0f) | 0x40;
    uuid[8] = (uuid[8] & 0x3f) | 0x80;
    return uuid;
}

var uuidNonce = 0;

function getUUIDNonce() {
    uuidNonce++;
    return uuidNonce;
}

function generateNewUUID() {
    return stringifyUUID(formatV4UUID(sha1forUUID(Date.now() + '-' + getUUIDNonce() + "-" + Math.random())));
}
// =========================== END gen UUID =====================
